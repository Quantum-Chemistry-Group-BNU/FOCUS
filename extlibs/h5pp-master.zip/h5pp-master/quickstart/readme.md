# Quick Start 

This section contains fully working examples for getting `h5pp` installed and ready to use in your project.

Inside each example directory, simply run the scripts in order. 

Study those scripts to customize your own build!
