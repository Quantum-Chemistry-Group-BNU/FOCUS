#include "hip/hip_runtime.h"
/*
    -- MAGMA (version 2.6.1) --
       Univ. of Tennessee, Knoxville
       Univ. of California, Berkeley
       Univ. of Colorado, Denver
       @date July 2021

       @author Ahmad Abdelfattah
       @author Azzam Haidar

       @generated from magmablas_hip/zgeqrf_batched_smallsq.hip.cpp, normal z -> s, Mon Jul 12 18:36:27 2021
*/

#include "magma_internal.h"
#include "magma_templates.h"
#include "sync.hip.hpp"
#include "batched_kernel_param.h"

#define SLDA(N)    ( (N==15||N==23||N==31)? (N+2) : (N+1) )
template<int N>
__global__ void
sgeqrf_batched_sq1d_reg_kernel( 
    float **dA_array, magma_int_t ldda,
    float **dtau_array, magma_int_t *info_array, 
    magma_int_t batchCount)
{
    HIP_DYNAMIC_SHARED( float, zdata)
    const int tx = threadIdx.x;
    const int ty = threadIdx.y; 
    const int batchid = blockIdx.x * blockDim.y + ty;
    if(batchid >= batchCount) return;
    if(tx >= N) return;
    
    const int slda  = SLDA(N);
    float* dA   = dA_array[batchid];
    float* dtau = dtau_array[batchid];
    magma_int_t* info = &info_array[batchid];
    // shared memory pointers
    float* sA = (float*)(zdata + ty * slda * N);
    float* sdw = (float*)(zdata + blockDim.y * slda * N);
    sdw += ty * N;

    float rA[N] = {MAGMA_S_ZERO};
    float alpha, tau, tmp, zsum, scale = MAGMA_S_ZERO;
    float sum = MAGMA_D_ZERO, norm = MAGMA_D_ZERO, beta; 

    if( tx == 0 ){
        (*info) = 0;
    }

    // init tau
    dtau[tx] = MAGMA_S_ZERO;
    // read 
    #pragma unroll
    for(int i = 0; i < N; i++){
        rA[i] = dA[ i * ldda + tx ];
    }
    
    #pragma unroll
    for(int i = 0; i < N-1; i++){
        sA[ i * slda + tx] = rA[i];
        sdw[tx] = ( MAGMA_S_REAL(rA[i]) * MAGMA_S_REAL(rA[i]) + MAGMA_S_IMAG(rA[i]) * MAGMA_S_IMAG(rA[i]) );
        magmablas_syncwarp();
        alpha = sA[i * slda + i];
        sum = MAGMA_D_ZERO; 
        #pragma unroll
        for(int j = i; j < N; j++){
            sum += sdw[j];
        }
        norm = sqrt(sum);
        beta = -copysign(norm, real(alpha));
        scale = MAGMA_S_DIV( MAGMA_S_ONE,  alpha - MAGMA_S_MAKE(beta, 0));
        tau = MAGMA_S_MAKE( (beta - real(alpha)) / beta, -imag(alpha) / beta );

        if(tx == i){
            dtau[i] = tau;
        }
        
        tmp = (tx == i)? MAGMA_S_MAKE(beta, MAGMA_D_ZERO) : rA[i] * scale;
        
        if(tx >= i){
            rA[i] = tmp;
        }
        
        dA[ i * ldda + tx ] = rA[i];
        rA[i] = (tx == i) ? MAGMA_S_ONE  : rA[i]; 
        rA[i] = (tx < i ) ? MAGMA_S_ZERO : rA[i];
        tmp = MAGMA_S_CONJ( rA[i] ) * MAGMA_S_CONJ( tau );
        
        magmablas_syncwarp();
        #pragma unroll
        for(int j = i+1; j < N; j++){
            sA[j * slda + tx] = rA[j] * tmp;
        }
        magmablas_syncwarp();

        zsum = MAGMA_S_ZERO;
        #pragma unroll
        for(int j = i; j < N; j++){
            zsum += sA[tx * slda + j];
        }
        sA[tx * slda + N] = zsum;
        magmablas_syncwarp();
        
        #pragma unroll
        for(int j = i+1; j < N; j++){
            rA[j] -= rA[i] * sA[j * slda + N];
        }
        magmablas_syncwarp();
    }
    // write the last column
    dA[ (N-1) * ldda + tx ] = rA[N-1];
}

/***************************************************************************//**
    Purpose
    -------
    SGEQRF computes a QR factorization of a real M-by-N matrix A:
    A = Q * R.
    
    This is a batched version of the routine, and works only for small 
    square matrices of size up to 32.
    
    Arguments
    ---------
    @param[in]
    n       INTEGER
            The size of the matrix A.  N >= 0.

    @param[in,out]
    dA_array Array of pointers, dimension (batchCount).
             Each is a REAL array on the GPU, dimension (LDDA,N)
             On entry, the M-by-N matrix A.
             On exit, the elements on and above the diagonal of the array
             contain the min(M,N)-by-N upper trapezoidal matrix R (R is
             upper triangular if m >= n); the elements below the diagonal,
             with the array TAU, represent the orthogonal matrix Q as a
             product of min(m,n) elementary reflectors (see Further
             Details).

    @param[in]
    ldda     INTEGER
             The leading dimension of the array dA.  LDDA >= max(1,M).
             To benefit from coalescent memory accesses LDDA must be
             divisible by 16.

    @param[out]
    dtau_array Array of pointers, dimension (batchCount).
             Each is a REAL array, dimension (min(M,N))
             The scalar factors of the elementary reflectors (see Further
             Details).

    @param[out]
    info_array  Array of INTEGERs, dimension (batchCount), for corresponding matrices.
      -     = 0:  successful exit

    @param[in]
    batchCount  INTEGER
                The number of matrices to operate on.

    @param[in]
    queue   magma_queue_t
            Queue to execute in.

    Further Details
    ---------------
    The matrix Q is represented as a product of elementary reflectors

       Q = H(1) H(2) . . . H(k), where k = min(m,n).

    Each H(i) has the form

       H(i) = I - tau * v * v'

    where tau is a real scalar, and v is a real vector with
    v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in A(i+1:m,i),
    and tau in TAU(i).

    @ingroup magma_geqrf_batched
*******************************************************************************/
extern "C" magma_int_t 
magma_sgeqrf_batched_smallsq( 
    magma_int_t n,  
    float** dA_array, magma_int_t ldda, 
    float **dtau_array, magma_int_t* info_array, 
    magma_int_t batchCount, magma_queue_t queue )
{
    magma_int_t arginfo = 0;
    magma_int_t m = n;
    if( (m < 0) || ( m > 32 ) ){
        arginfo = -1;
    }

    if (arginfo != 0) {
        magma_xerbla( __func__, -(arginfo) );
        return arginfo;
    }
    
    if( m == 0 || n == 0) return 0;
    
    const magma_int_t ntcol = magma_get_sgeqrf_batched_ntcol(m, n);
    
    magma_int_t shmem = ( SLDA(m) * m * sizeof(float) );
    shmem            += ( m * sizeof(float) );
    shmem            *= ntcol;
    magma_int_t nth = magma_ceilpow2(m);
    magma_int_t gridx = magma_ceildiv(batchCount, ntcol);
    dim3 grid(gridx, 1, 1);
    dim3 threads(nth, ntcol, 1);
    
    switch(m){
        
        case  1: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 1>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  2: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 2>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  3: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 3>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  4: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 4>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  5: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 5>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  6: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 6>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  7: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 7>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  8: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 8>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case  9: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel< 9>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 10: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<10>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 11: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<11>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 12: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<12>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 13: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<13>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 14: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<14>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 15: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<15>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 16: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<16>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 17: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<17>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 18: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<18>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 19: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<19>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 20: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<20>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 21: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<21>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 22: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<22>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 23: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<23>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 24: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<24>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 25: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<25>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 26: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<26>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 27: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<27>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 28: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<28>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 29: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<29>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 30: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<30>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 31: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<31>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        case 32: hipLaunchKernelGGL(HIP_KERNEL_NAME(sgeqrf_batched_sq1d_reg_kernel<32>), dim3(grid), dim3(threads), shmem, queue->hip_stream(), dA_array, ldda, dtau_array, info_array, batchCount); break;
        default: printf("error: size %lld is not supported\n", (long long) m);
    }
    return arginfo;
}
